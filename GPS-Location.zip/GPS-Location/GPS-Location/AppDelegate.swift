//
//  AppDelegate.swift
//  GPS-Location
//
//  Created by Anil Kumar on 12/06/24.
//

import UIKit
import CoreData

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var navigationController: UINavigationController?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        setRootController(GPSLocationViewController())
        return true
    }
    
    // MARK: - Core Data stack
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "GPS_Location")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    // MARK: - Core Data Saving support
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}
//MARK: - Set Root controller
extension AppDelegate{
    func setRootController(_ viewController: UIViewController){
        window = UIWindow(frame: UIScreen.main.bounds)
        navigationController = UINavigationController(rootViewController: viewController)
        navigationController?.navigationBar.isHidden = true
        navigationController?.delegate = self
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
    }
}
extension AppDelegate: UINavigationControllerDelegate {
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        if let gestureRecognizer = navigationController.interactivePopGestureRecognizer {
            gestureRecognizer.isEnabled = false
            gestureRecognizer.removeTarget(nil, action: nil)
        }
    }
}
