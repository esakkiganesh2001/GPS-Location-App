//
//  GPSLocationViewController.swift
//  GPS-Location
//
//  Created by Anil Kumar on 12/06/24.
//
import UIKit
import MapKit
import CoreLocation

class GPSLocationViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    private lazy var mapView: MKMapView = {
        let map = MKMapView()
        map.overrideUserInterfaceStyle = .dark
        map.delegate = self
        map.translatesAutoresizingMaskIntoConstraints = false
        return map
    }()
    
    private lazy var mapButton: UIButton! = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints    =   false
        button.setImage(UIImage(named: "map_icon"), for: .normal)
        button.addTarget(self, action: #selector(didTapMapTypes), for: .touchUpInside)
        return button
    }()
    
    private lazy var locationButton: UIButton! = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints    =   false
        button.setTitle("Start Location", for: .normal)
        button.addTarget(self, action: #selector(didtapLocationButton), for: .touchUpInside)
        button.backgroundColor = .systemBlue
        button.titleLabel?.font = .boldSystemFont(ofSize: 18)
        button.layer.cornerRadius = 10
        return button
    }()
    private var currentLocation: CLLocation?
    private var mapTypes        =   [MapType]()
    let locationManager = CLLocationManager()
    var startingCoordinate: CLLocationCoordinate2D? {
        guard let location = currentLocation else { return nil }
        return location.coordinate
    }
    
    override func loadView() {
        super.loadView()
        setMapConstraints()
        createMapType()
        view.backgroundColor = .white
        title = "GPS Location Services"
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        if let startingCoordinate = startingCoordinate {
            drawLineBetweenLocations(startCoordinate: startingCoordinate,
                                     endCoordinate: CLLocationCoordinate2D(latitude: 11.0238, longitude: 76.9452))
        }
    }
    
    private func setMapConstraints() {
        view.addSubview(mapView)
        view.addSubview(mapButton)
        view.addSubview(locationButton)
        NSLayoutConstraint.activate([
            
            mapButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            mapButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            mapButton.widthAnchor.constraint(equalToConstant: 50),
            mapButton.heightAnchor.constraint(equalToConstant: 50),
            
            locationButton.bottomAnchor.constraint(equalTo: mapView.bottomAnchor, constant: -55),
            locationButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            locationButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            locationButton.heightAnchor.constraint(equalToConstant: 50),
            
            mapView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50),
            mapView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    private func drawLineBetweenLocations(startCoordinate: CLLocationCoordinate2D, endCoordinate: CLLocationCoordinate2D) {
        let startPlacemark = MKPlacemark(coordinate: startCoordinate, addressDictionary: nil)
        let endPlacemark = MKPlacemark(coordinate: endCoordinate, addressDictionary: nil)
        
        let startMapItem = MKMapItem(placemark: startPlacemark)
        let endMapItem = MKMapItem(placemark: endPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = startMapItem
        directionRequest.destination = endMapItem
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] (response, error) in
            guard let self = self else { return }
            guard let response = response else {
                if let error = error {
                    print("Error calculating directions: \(error.localizedDescription)")
                }
                return
            }
            let route = response.routes[0]
            self.mapView.addOverlay(route.polyline)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
            mapView.setRegion(region, animated: true)
            addStartingPointAnnotation()
            locationManager.stopUpdatingLocation()
        }
    }
    
    private func addStartingPointAnnotation() {
        let annotation = MKPointAnnotation()
        if let startingCoordinate = startingCoordinate {
            annotation.coordinate = startingCoordinate
            annotation.title = "Starting Point"
            mapView.addAnnotation(annotation)
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }
        
        let identifier = "StartingPointAnnotation"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        if annotationView == nil {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            if let image = UIImage(named: "driver-Images") {
                let resizedImage = image.resized(to: CGSize(width: 50, height: 50))
                annotationView?.image = resizedImage
                annotationView?.canShowCallout = true
            }
        } else {
            annotationView?.annotation = annotation
        }
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = .systemBlue
            renderer.lineWidth = 8
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }
}
extension GPSLocationViewController {
    
    @objc
    private func didtapLocationButton() {
        
    }
    @objc
    private func didTapMapTypes() {
        
        let mapTypeSheet        =   UIAlertController.init(title: "Select Map Type",
                                                           message: nil,
                                                           preferredStyle: .actionSheet)
        
        let standardMapAction   =   UIAlertAction(title: "Standard",
                                                  style: .default) { [self] (_) in
            changeMapType(with: 0)
        }
        
        let satelliteMapAction  =   UIAlertAction(title: "Satellite",
                                                  style: .default) { [self] (_) in
            changeMapType(with: 1)
        }
        
        let hybridMapAction     =   UIAlertAction(title: "Hybrid",
                                                  style: .default) { [self] (_) in
            changeMapType(with: 2)
        }
        
        let cancelAction        =   UIAlertAction(title: "Cancel",
                                                  style: .cancel, handler: nil)
        
        mapTypeSheet.addAction(standardMapAction)
        mapTypeSheet.addAction(satelliteMapAction)
        mapTypeSheet.addAction(hybridMapAction)
        mapTypeSheet.addAction(cancelAction)
        
        present(mapTypeSheet, animated: true, completion: nil)
    }
    
    private func changeMapType(with index: Int) {
        for values in 0...2 {
            self.mapTypes[values].isSelected = values == index ? true : false
        }
        switch index {
        case 0:
            mapView.mapType   =   .standard
            break
        case 1:
            mapView.mapType   =   .satellite
            break
        case 2:
            mapView.mapType   =   .hybrid
            break
        default:
            mapView.mapType   =   .standard
            break
        }
    }
    
    private func createMapType() {
        mapTypes.append(MapType(title: "Standard", isSelected: true))
        mapTypes.append(MapType(title: "Satellite", isSelected: false))
        mapTypes.append(MapType(title: "Hybrid", isSelected: false))
    }
}

struct MapType {
    var title: String
    var isSelected: Bool
}
extension UIImage {
    func resized(to newSize: CGSize) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(newSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: newSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
}
